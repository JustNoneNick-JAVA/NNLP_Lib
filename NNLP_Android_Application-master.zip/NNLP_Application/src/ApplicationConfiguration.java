import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;

public class ApplicationConfiguration {
	
	public static void main(String[] args) {
		LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
		config.width = AndroidManager.WIDTH;
		config.height = AndroidManager.HEIGHT;
		config.title = AndroidManager.TITLE;
		
		new LwjglApplication(new Activity(), config);
	}
	
}
