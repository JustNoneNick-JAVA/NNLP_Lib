import com.badlogic.gdx.backends.android.AndroidApplication;
import com.badlogic.gdx.backends.android.AndroidApplicationConfiguration;

import android.os.Bundle;

public class AndroidManager extends AndroidApplication {
	
	public static final String TITLE = "Android App";
	public static final int WIDTH = 480;
	public static final int HEIGHT = 800;
	
	protected void onCreate (Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		AndroidApplicationConfiguration config = new AndroidApplicationConfiguration();
		initialize(new Activity(), config);
	}
	
}
